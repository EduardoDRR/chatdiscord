function Home() {
  return (
    <div>
      <h1>Inicio</h1>
    </div>
  );
}
